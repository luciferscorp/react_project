import React, { useState } from 'react';
import RegisterPage from '../screen/Register/Register';

const Popup = (props) => {
  const [isModalOpen, setIsModalOpen] = useState(false);

  const openModal = () => {
    setIsModalOpen(true);
  };

  const closeModal = (e) => {
    setIsModalOpen(false);
  };

  return (
    <div>
      <button onClick={openModal}>Open Modal</button>

      {isModalOpen && (
        <div className="modal">
          <div className="modal-content">
            {/* <span className="close" onClick={closeModal}>
              &times;
            </span> */}
            <RegisterPage function={()=>setIsModalOpen(false)}/>
            {/* {props.item} */}
          </div>
        </div>
      )}
    </div>
  );
};

export default Popup;