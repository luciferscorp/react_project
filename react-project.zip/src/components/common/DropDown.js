import React from 'react'
import { useState } from 'react'

import '../asserts/css/DropDown.css'

const Option = ({ values }) => {
   return (
    <option >{values}</option>
  )
}

const DropDown = ({id,Title,values,classfield}) => {

  return (
    <div >
      <div className={classfield} id={id}>
        <div class="top-option"  disabled selected>
          <div className='dropdown-title'>{Title}</div>
        </div>
        { values.map((element) =>
        
        <option  className='option-list'>{element}</option>)}
      </div>
    </div>
  )

  // <DropDown id="values" Tile="Select Role" values=['Project Manager','Project Leader','Team Member']  />
}

export default DropDown;









