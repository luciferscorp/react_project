import React, { useState, useEffect } from 'react';
import * as FaIcons from 'react-icons/fa';
import { Link, useLocation } from 'react-router-dom';
import '../asserts/css/Sidebar.css'
import { IconContext } from 'react-icons';

//Sidebar Data
import { SidebarData } from './SidebarData';
import { admin_options } from './Roles/admin_options';
import { projectLeader_options } from './Roles/projectLeader_options';
import { projectManager_options } from './Roles/projectManager_options';
import { employee_options } from './Roles/employee_options';


function Sidebar() {
  const [sidebar, setSidebar] = useState(true);
  const showSidebar = () => setSidebar(!sidebar || false);

  const [role, setRole] = useState("projectManager");
  const [data, setData] = useState([]);


  useEffect(() => {

    //  setRole({"name":"projectManager"})
    if (role === "Admin") {
      setData(SidebarData.admin_options)
    }
    else if (role === "projectManager") {
      setData(SidebarData.projectManager_options)

    }
    else if (role === "projectLeader") {
      setData(SidebarData.projectLeader_options)

    }
    else if (role === "employee_options") {
      setData(SidebarData.employee_options)

    }

    // console.log("role",{"rr":"projectManager"});

    // setTimeout(() => {
    //    console.log("role",role);

    // }, 2000);


  }, [role])
const location= useLocation();

  return (
    <>
      <div className='sidebar-body'>
        <IconContext.Provider value={{ color: '#fff' }}>
          <div className='sidebar'> 
            <Link to='#' className='menubaropen'>
              <FaIcons.FaBars onClick={() => showSidebar()} />
            </Link>
          </div>
          <nav className={sidebar ? 'navmenu active' : 'navmenu'}>
            <ul className='navmenuitems'>
              <li className='navbartoggle' onClick={() => showSidebar()}>
                <Link to='#' className='menubarclose'>
                  <FaIcons.FaBars />
                </Link>
              </li>

              {data.map((item, index) => {
                return (
                  <li key={index} className={item.cName}>
                    <Link to={item.path} className={item.path ==location.pathname ? "nav-text-active": ""} >
                      {item.icon}
                      <span>{item.title}</span>
                    </Link>
                  </li>
                );
              })}
            </ul>

          </nav>
        </IconContext.Provider>
      </div>
    </>
  );
}

export default Sidebar;