import React from 'react'

import '../../asserts/css/Home.css'
import RegisterPage from '../Register/Register'
import Navbar from '../../common/Navbar'
import Sidebar from '../../common/Sidebar'

function Home() {
  return (
    <>
    <div className='home-body'>

      <Navbar />
      <Sidebar />
      <RegisterPage />

    </div>
    </>
  )
}

export default Home