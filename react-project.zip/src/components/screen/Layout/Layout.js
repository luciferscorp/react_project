import React from 'react'

import '../../asserts/css/Home.css'
import RegisterPage from '../Register/Register'
import Navbar from '../../common/Navbar'
import Sidebar from '../../common/Sidebar'
import Popup from '../../common/Popup'


function Layout() {
  return (
    <>
    <div className='home-body'>

      
      <Popup />
    </div>
    </>
  )
}

export default Layout;