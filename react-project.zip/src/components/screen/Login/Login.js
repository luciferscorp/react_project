import '../../asserts/css/LoginPage.css'
import Sidebar from '../../common/Sidebar';
import Input from '../../common/Input.js'
import Button from '../../common/Button.js'
import {useState} from 'react'

function LoginPage() {
    // const [placeholder1, setplaceholder1] = useState("");

  return (
    <>
    <div className='login-body'>
      <div class="container">
        <form>
          <div>
            <h3>Login </h3>
          </div>
          <div>
            <Input type="email" id="email" name="username" placeholder="Email" classfield="inputField" />
          </div>
          <div>
            <Input  type="password" id="password" name="password" placeholder="Password" classfield="inputField"/>
          </div>
          <div className="error">
            <span class="spanEnd" id="error"></span>
          </div>
          <div>
            <Button type="button" Title="Submit"/>
          </div>
        </form>
      </div>
      </div>
    </>
    
  );
}

export default LoginPage;