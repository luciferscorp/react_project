import React from 'react'
import '../assets/css/Navbar.css'
import { IoIosNotifications } from "react-icons/io";
import { IconContext } from 'react-icons';
import profile_image from '../assets/images/blank-profile-picture-30x30.webp'

const Navbar = () => {
    
    return (
        <div className='navbar'>
            <IconContext.Provider value={{ color: '#fff' }}>
                <ul className='navbar-items'>
                    <li className='notif-icon'>
                        <IoIosNotifications />
                    </li>
                    <li className='profile'>
                       
                        <img src={profile_image} alt='profile' />

                    </li>
                </ul>
            </IconContext.Provider>
        </div>
    )
}

export default Navbar
