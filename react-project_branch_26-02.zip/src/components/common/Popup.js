import React, { useState } from 'react';
import './../assets/css/Popup.css';


const Popup = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);

  const openModal = () => {
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
  };

  return (
    <div>
      <button className="popup-openBtn" onClick={openModal}>Open Modal</button>

      {isModalOpen && (
        <div className="model-contant">
          <div className="popup-modal">
            <span className="popup-close-button" onClick={closeModal}>
              &times;
            </span>
            <h2>Hi Everyone</h2>
            <p>Welcome to my website .We are thrilled to have you here.Start your journey now!</p>
          </div>
        </div>
      )}
    </div>
  );
};
    

export default Popup;