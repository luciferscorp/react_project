import React from 'react'
import { useState } from 'react'

import '../assets/css/DropDown.css'

const Option = ({ values }) => {
  return (
    <option >{values}</option>
  )
}

const DropDown = ({id,Title,values,classfield}) => {

  return (
    <div >
      <select className={classfield} id={id}>
        <option class="top-option"  disabled selected>
          <div className='dropdown-title'>{Title}</div>
        </option>
        { 
        values.map((element) => <option className='option-list'>{element}</option>)}
      </select>
    </div>
  )

  // <DropDown id="values" Tile="Select Role" values=['Project Manager','Project Leader','Team Member']  />
}

export default DropDown;









