import React, { useState, useEffect } from 'react'

import '../../assets/css/Home.css'
import RegisterPage from '../Register/Register'
import Navbar from '../../common/Navbar'
import Sidebar from '../../common/Sidebar'
import Popup from '../../common/Popup'


function Layout() {

  const [backendData, setBackenData] = useState();


  useEffect(() => {
    fetch("/api").then(
      response => response.json()
    ).then(
      data => setBackenData(data)
    )
  },[])

  return (
    <>
      <div>

      </div>
    </>
  )
}

export default Layout;

