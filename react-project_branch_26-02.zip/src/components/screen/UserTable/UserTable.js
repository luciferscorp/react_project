import React , {useEffect }from 'react'

import Navbar from '../../common/Navbar'
import Sidebar from '../../common/Sidebar'
import Pagination from '../../common/Pagination'


function UserTable() {
  return (
    <>
    <div className='home-body'>

      <Navbar />
      <Sidebar />
      <Pagination />

    </div>
    </>
  )
}

export default UserTable