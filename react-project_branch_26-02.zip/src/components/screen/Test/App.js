import React, { useState, useEffect } from 'react'
import data from './components/common/data.json'
import './App.css'
import Button from "../src/Button.js"



function App() {


    const [currentPage, setCurrentPage] = useState(1)
    const recordPerPage = 5;
    const lastIndex = currentPage * recordPerPage;
    const firstIndex = lastIndex - recordPerPage;
    const records = data.slice(firstIndex, lastIndex);
    const npage = Math.ceil(data.length / recordPerPage)
    const numbers = [...Array(npage + 1).keys()].slice(1)


    useEffect(() => { console.log("records", setCurrentPage); }, [currentPage])



    return (

        <div className="emp-bodycontainer">


           {/* <div className="emp-tablebutton">
                <Button Type="submit" Title='Button' />
    </div>*/}

            <div className='emp-tablecontainer'>


                <table className="emp-tablecontent">

                    <thead>
                        <th className='emp-tablehead'>id</th>
                        <th className='emp-tablehead'>firstName</th>
                        <th className='emp-tablehead'>lastName</th>
                        <th className='emp-tablehead'>maidenName</th>
                        <th className='emp-tablehead'>age</th>
                        <th className='emp-tablehead'>gender</th>
                        <th className='emp-tablehead'>email</th>
                    </thead>

                    <tbody >
                        {records.map((keyOfArray, Value) => (
                            <tr className='emp-tablebody'>
                                <td className='emp-tabledata'>{keyOfArray.id}</td>
                                <td className='emp-tabledata'>{keyOfArray.firstName}</td>
                                <td className='emp-tabledata'>{keyOfArray.lastName}</td>
                                <td className='emp-tabledata'>{keyOfArray.maidenName}</td>
                                <td className='emp-tabledata'>{keyOfArray.age}</td>
                                <td className='emp-tabledata'>{keyOfArray.gender}</td>
                                <td className='emp-tabledata'>{keyOfArray.email}</td>
                            </tr>
                        ))}
                    </tbody>

                </table>


            </div>




            <nav className='emp-navbar'>

                <ul className='emp-pagination'>
                    <li className='emp-page-item'>
                        <a href='#' className='emp-page-link' onClick={prePage}>Prev</a>
                    </li>
                    {

                        numbers.map((n, i) => (
                            <li className={`emp-page-item ${currentPage === n ? 'active' : ''}`} key={i}>
                                <a href='#' className='emp-page-item' onClick={changePage}>{n}</a>
                            </li>
                            
                        ))
                    }
                    <li className='emp-page-item'>
                        <a href='#' className='emp-page-link' onClick={nextPage}>Next</a>
                    </li>
                </ul>
            </nav>


        </div>


    )




    function prePage() {
        if (currentPage !== 1) {
            setCurrentPage(currentPage - 1)
        }
    }

    function changePage(newdt) {
        setCurrentPage(newdt)
    }

    function nextPage() {
        if (currentPage !== npage) {
            setCurrentPage(currentPage + 1)
        }
    }




}


export default App;