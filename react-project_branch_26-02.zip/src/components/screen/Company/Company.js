import React from 'react'
import '../../assets/css/Home.css'
import Navbar from '../../common/Navbar'
import Sidebar from '../../common/Sidebar'



function Company() {
  return (
    <>
      <div className='home-body'>

        <Navbar />
        <Sidebar role="admin" />
        <div className='center-contant'> <h1 >Company Details</h1></div>

      </div>
    </>
  )
}

export default Company;