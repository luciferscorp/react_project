import ReactDOM from "react-dom/client";
import { createBrowserRouter, RouterProvider, BrowserRouter, Routes, Route } from "react-router-dom";
import Home from './components/screen/Home/Home.js'
import RegisterPage from './components/screen/Register/Register.js'
import LoginPage from "./components/screen/Login/Login.js";
import Layout from "./components/screen/Layout/Layout.js";
import DropDown from "./components/common/DropDown.js";
import UserTable from "./components/screen/UserTable/UserTable.js";
import Pagination from "./components/common/Pagination.js";
import Admin from "./components/screen/Admin/Admincompany.js";
import Employee from "./components/screen/Employee/Employee.js";
import Company from "./components/screen/Company/Company.js";


const router = createBrowserRouter([
  {
    path: "/",
    element: <Home />,
  },
  {
    path: "/Login",
    element: <LoginPage />,
  },
  {
    path: "/Register",
    element: <RegisterPage />,
  },
  {
    path: "/Layout",
    element: <Layout />,
  },
  {
    path: "/Test",
    element: <Pagination />,
  },
  {
    path: "/UserTable",
    element: <UserTable />,
  },
  {
    path: "/Admin",
    element: <Admin />,
  },
  {
    path: "/employee",
    element: <Employee />,
  },
  {
    path: "/company",
    element: <Company />,
  },
]);


const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<RouterProvider router={router} />)
